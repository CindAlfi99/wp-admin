<?php
define('BASE_URL','http://localhost/rl381-adm');
define('ROOT','http://localhost/rl381-adm/');
?>